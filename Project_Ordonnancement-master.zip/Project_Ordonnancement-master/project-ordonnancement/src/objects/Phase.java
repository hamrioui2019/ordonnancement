package objects;

public class Phase {
	public int id;
	public int duree;
	public int machine;
	
	public Phase (int id, int machine, int duree) {
		this.id = id;
		this.duree = duree;
		this.machine = machine;
	}
}
