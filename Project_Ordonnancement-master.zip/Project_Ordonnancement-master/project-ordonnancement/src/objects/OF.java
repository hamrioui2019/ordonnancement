package objects;

public class OF {
	public int due_date;
	public int nb;
	public Phase []phases;
	
	public OF (int due_date, int nb) {
		this.due_date = due_date;
		this.nb = nb;
		this.phases = new Phase[nb];
	}
}
