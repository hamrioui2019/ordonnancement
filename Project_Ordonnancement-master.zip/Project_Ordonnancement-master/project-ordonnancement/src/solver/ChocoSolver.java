package solver;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import org.chocosolver.solver.Model;
import org.chocosolver.solver.Solver;
import org.chocosolver.solver.variables.IntVar;

import objects.OF;
import objects.Phase;

public class ChocoSolver {
	
	public boolean solve() {
		
		// define fixed OF 23, 24 and 25
		OF OF_23 = new OF(12, 2);
        OF_23.phases[0] = new Phase(1,3,3);
        OF_23.phases[1] = new Phase(2,1,6);
        
        OF OF_24 = new OF(12, 2);
        OF_24.phases[0] = new Phase(1,2,4);
        OF_24.phases[1] = new Phase(2,4,5);
        
        OF OF_25 = new OF(8, 2);
        OF_25.phases[0] = new Phase(1,4,2);
        OF_25.phases[1] = new Phase(2,3,3);
        
		//define others OFs
		
		OF OF_26 = new OF(32, 4);
        OF_26.phases[0] = new Phase(1,1,4);
        OF_26.phases[1] = new Phase(2,3,4);
        OF_26.phases[2] = new Phase(3,2,9);
        OF_26.phases[3] = new Phase(4,4,5);
        
        OF OF_27 = new OF(16, 2);
        OF_27.phases[0] = new Phase(1,4,5);
        OF_27.phases[1] = new Phase(2,3,4);

        OF OF_28 = new OF(32, 2);
        OF_28.phases[0] = new Phase(1,2,10);
        OF_28.phases[1] = new Phase(2,3,13);
        
        OF OF_29 = new OF(75, 6);
        OF_29.phases[0] = new Phase(1,1,9);
        OF_29.phases[1] = new Phase(2,2,6);
        OF_29.phases[2] = new Phase(3,4,5);
        OF_29.phases[3] = new Phase(4,2,9);
        OF_29.phases[4] = new Phase(5,3,10);
        OF_29.phases[5] = new Phase(6,2,8);
        
        OF OF_30 = new OF(67, 3);
        OF_30.phases[0] = new Phase(1,4,14);
        OF_30.phases[1] = new Phase(2,1,18);
        OF_30.phases[2] = new Phase(3,4,15);
        
        OF OF_31 = new OF(51, 2);
        OF_31.phases[0] = new Phase(1,2,7);
        OF_31.phases[1] = new Phase(2,3,9);
        
        OF OF_32 = new OF(63, 4);
        OF_32.phases[0] = new Phase(1,1,7);
        OF_32.phases[1] = new Phase(2,3,5);
        OF_32.phases[2] = new Phase(3,4,12);
        OF_32.phases[3] = new Phase(4,2,7);
        
        OF OF_33 = new OF(71, 4);
        OF_33.phases[0] = new Phase(1,3,4);
        OF_33.phases[1] = new Phase(2,2,3);
        OF_33.phases[2] = new Phase(3,1,4);
        OF_33.phases[3] = new Phase(4,3,7);
        
		Model model = new Model("chocosolver");	
	    
		//to store OFs var created
		ArrayList<IntVar[][]> listOF = new ArrayList<IntVar[][]>();
		
		// init var for fixed OFs
		IntVar[][]OF23 = new IntVar[OF_23.nb][4];
		IntVar[][]OF24 = new IntVar[OF_24.nb][4];
		IntVar[][]OF25 = new IntVar[OF_25.nb][4];
		
		//define domain and precedence constraints for fixed OFs
		defineDomain(OF23, OF_23, model, listOF);
		OF23[0][2] = model.intVar(0);
		OF23[0][3] = model.intVar(3);
		OF23[1][2] = model.intVar(6);
		OF23[1][3] = model.intVar(12);
		defineConstraintsPrec(OF23, OF_23, model);
				
		defineDomain(OF24, OF_24, model, listOF);
		OF24[0][2] = model.intVar(0);
		OF24[0][3] = model.intVar(4);
		OF24[1][2] = model.intVar(7);
		OF24[1][3] = model.intVar(12);
		defineConstraintsPrec(OF24, OF_24, model);
				
		defineDomain(OF25, OF_25, model, listOF);
		OF25[0][2] = model.intVar(0);
		OF25[0][3] = model.intVar(2);
		OF25[1][2] = model.intVar(5);
		OF25[1][3] = model.intVar(8);
		defineConstraintsPrec(OF25, OF_25, model);
		
		
		//init var for others OFs
		
		IntVar[][]OF26 = new IntVar[OF_26.nb][4];
		IntVar[][]OF27 = new IntVar[OF_27.nb][4];
		IntVar[][]OF28 = new IntVar[OF_28.nb][4];
		IntVar[][]OF29 = new IntVar[OF_29.nb][4];
		IntVar[][]OF30 = new IntVar[OF_30.nb][4];
		IntVar[][]OF31 = new IntVar[OF_31.nb][4];
		IntVar[][]OF32 = new IntVar[OF_32.nb][4];
		IntVar[][]OF33 = new IntVar[OF_33.nb][4];
		
		//define domain and precedence constraints for others OFs
		defineDomain(OF26, OF_26, model, listOF);
		defineConstraintsPrec(OF26, OF_26, model);
		
		defineDomain(OF27, OF_27, model, listOF);
		defineConstraintsPrec(OF27, OF_27, model);
		
		defineDomain(OF28, OF_28, model, listOF);
		defineConstraintsPrec(OF28, OF_28, model);
		
		defineDomain(OF29, OF_29, model, listOF);
		defineConstraintsPrec(OF29, OF_29, model);
		
		defineDomain(OF30, OF_30, model, listOF);
		defineConstraintsPrec(OF30, OF_30, model);
		
		defineDomain(OF31, OF_31, model, listOF);
		defineConstraintsPrec(OF31, OF_31, model);
		
		defineDomain(OF32, OF_32, model, listOF);
		defineConstraintsPrec(OF32, OF_32, model);
		
		defineDomain(OF33, OF_33, model, listOF);
		defineConstraintsPrec(OF33, OF_33, model);
		
		//define list of OFs and precedence constraints on each machine
		ArrayList<IntVar[]>listMachine1 = defineListMachine(listOF, 1, model);
		ArrayList<IntVar[]>listMachine2 = defineListMachine(listOF, 2, model);
		ArrayList<IntVar[]>listMachine3 = defineListMachine(listOF, 3, model);
		ArrayList<IntVar[]>listMachine4 = defineListMachine(listOF, 4, model);
		
		defineMachineConstraints(listMachine1, model);
		defineMachineConstraints(listMachine2, model);
		defineMachineConstraints(listMachine3, model);
		defineMachineConstraints(listMachine4, model);
		
		
		// to test optimality of solution Cmax = 74 and Cmeans = 430
		/*IntVar Cmax = model.intVar(0,73);
		IntVar Cmeans = model.intVar(0,429);
		
		IntVar[] Cmean = new IntVar[listOF.size()];
		int cpt = 0;
		for (IntVar[][] OF : listOF) {
			Cmean[cpt] = OF[OF.length-1][3];
			model.arithm(Cmax, ">=", OF[OF.length-1][3]).post();
			cpt++;
		}
		model.sum(Cmean, "<=", Cmeans).post();
		
		model.setObjective(Model.MINIMIZE, Cmeans);
		//model.setObjective(Model.MINIMIZE, Cmax);
		Solver solver = model.getSolver();
		//boolean resolution = solver.solve();
		boolean resolution = false;
		while(solver.solve()){
		    resolution = true;
		    calculPerf(listOF);
		    System.out.println(Cmeans.getValue());
		    System.out.println(Cmax.getValue());
		}*/
		
		Solver solver = model.getSolver();
		boolean resolution = solver.solve();
		
		//Display of solution and performances
		
		System.out.println("Ordonnancement \n");
		this.translate(listOF);
		System.out.println("Machine 1\n");
		this.translateMachine(listMachine1);
		System.out.println("Machine 2\n");
		this.translateMachine(listMachine2);
		System.out.println("Machine 3\n");
		this.translateMachine(listMachine3);
		System.out.println("Machine 4\n");
		this.translateMachine(listMachine4);
		calculPerf(listOF);
		return resolution;
	}
	
	//define domain of each OF
	public void defineDomain(IntVar[][] var, OF Of, Model model, ArrayList<IntVar[][]> listOF) {
		int Cmin = -3;
		for (int i = 0; i<Of.nb; i++) {
			Cmin += Of.phases[i].duree + 3;		
		}
		
		var[0][0] = model.intVar(Of.phases[0].duree); //duree
		var[0][1] = model.intVar(Of.phases[0].machine); //machine
		var[0][2] = model.intVar(0,Of.due_date-Cmin); //start date
		var[0][3] = model.intVar(Of.phases[0].duree,Of.due_date - Cmin + Of.phases[0].duree); //end date
				
		int temp_min= 0;
		int temp_max = Of.due_date-Cmin;
		for (int i = 1; i<Of.nb; i++) {
			temp_min += Of.phases[i-1].duree + 3;
			temp_max += Of.phases[i-1].duree + 3;
			
			var[i][0] = model.intVar(Of.phases[i].duree); //duree
			var[i][1] = model.intVar(Of.phases[i].machine); //machine
			var[i][2] = model.intVar(temp_min,temp_max); //start date
			var[i][3] = model.intVar(temp_min + Of.phases[i].duree,temp_max + Of.phases[i].duree); //end date
		}
		
		listOF.add(var);

		return;
	}
	
	//define list of phases on a machine
	public ArrayList<IntVar[]> defineListMachine(ArrayList<IntVar[][]>listOF, int id, Model model){
		ArrayList<IntVar[]> listMachine = new ArrayList<IntVar[]>();
		int OFid = 22;
		for (IntVar[][] OF : listOF) {
			OFid++;
			for (int i = 0; i<OF.length; i++) {
				if (OF[i][1].getValue() == id) {
					IntVar[] temp = new IntVar[4];
					temp[0] = OF[i][2];
					temp[1] = OF[i][3];
					temp[2] = model.intVar(OFid);
					temp[3] = model.intVar(i+1);
					listMachine.add(temp);
				}
			}
		}
		return listMachine;
	}
	
	//define precedence constraints for an OF
	public void defineConstraintsPrec(IntVar[][] var, OF Of, Model model) {
		IntVar InterOp = model.intVar(3);
		for (int i = 0; i< Of.nb-1; i++) {
			model.arithm(var[i][2],"+",var[i][0],"=",var[i][3]).post();
			model.arithm(var[i][3],"+",InterOp,"<=",var[i+1][2]).post();
		}

		model.arithm(var[Of.nb-1][2],"+",var[Of.nb-1][0],"=",var[Of.nb-1][3]).post();
		
		return;
	}
	
	//define precedence constraints for a machine
	public void defineMachineConstraints(ArrayList<IntVar[]> listMachine, Model model) {
		if (listMachine.size()<=1) {
			return;
		}
		
		for (IntVar[] phase1 : listMachine) {
			for (IntVar[] phase2 : listMachine) {
				if (phase1 != phase2) {
					IntVar order1 = model.intVar(0,1);
					IntVar order2 = model.intVar(0,1);
					
					model.arithm(order1,"+",order2,"=",1).post();
					
					model.arithm(phase1[0],">=",phase2[1],"*",order1).post();
					model.arithm(phase2[0],">=",phase1[1],"*",order2).post();
					
				}
			}
		}
	}
	
	//display OFS
	public void translate(ArrayList<IntVar[][]> listOF) {
		int OFid = 22;
		for (IntVar[][] OF : listOF) {
			OFid++;
			System.out.println("OF "+OFid);
			for (int i = 0; i < OF.length; i++) {
				int phase = i+1;
				System.out.println("Phase :"+phase);
				System.out.println("machine : " + OF[i][1].getValue()+"   duree : " + OF[i][0].getValue());
				System.out.println("debut : "+ translateToStartDay(OF[i][2].getValue()));
				System.out.println("fin : "+ translateToEndDay(OF[i][3].getValue()));
			}
			System.out.println("\n");
		}
	}
	
	//display phases order on a machine
	public void translateMachine(ArrayList<IntVar[]> listOF) {
		Collections.sort(listOF, new Comparator<IntVar[]>() {
		    @Override
		    public int compare(IntVar[] tc1, IntVar[] tc2) {
		    	if (tc1[0].getValue()>tc2[0].getValue()) {
		    		return 1;
		    	}
		    	else {
		    		return -1;
		    	}
		    }
		});
		for (IntVar[] OF : listOF) {
			System.out.println("OF : "+OF[2].getValue()+"  phase : "+OF[3].getValue());
			System.out.println("debut : "+ translateToStartDay(OF[0].getValue()));
			System.out.println("fin : "+ translateToEndDay(OF[1].getValue()));
		}
		System.out.println("\n");
	}
	
	// to define week, day and hour start time of a task
	public String translateToStartDay(int time){
		String s = "";
		if (time < 39){
			s += "Semaine i ";	
		}
		else{
			s += "Semaine i+1 ";
			time = time - 39;
		}
		int day = time/8;
		int hour = time%8;
		switch (day) {
		case 0 : 
			s += "Lundi � ";
			break;
		case 1 : 
			s += "Mardi � ";
			break;
		case 2 : 
			s += "Mercredi � ";
			break;
		case 3 : 
			s += "Jeudi � ";
			break;	
		case 4 : 
			s += "Vendredi � ";
			break;	
		}
		if (hour <4) {
			s += hour+8+"h";
		}
		else {
			s += hour+9+"h";
		}
		return s;
	}
	
	// to define week, day and hour end time of a task
	public String translateToEndDay(int time){
		String s = "";
		if (time <= 39){
			s += "Semaine i ";	
		}
		else{
			s += "Semaine i+1 ";
			time = time - 39;
		}
		int day = time/8;
		int hour = time%8;
		if (hour == 0 && day!=0) {
				day = day -1;
		}
		switch (day) {
		case 0 : 
			s += "Lundi � ";
			break;
		case 1 : 
			s += "Mardi � ";
			break;
		case 2 : 
			s += "Mercredi � ";
			break;
		case 3 : 
			s += "Jeudi � ";
			break;	
		case 4 : 
			s += "Vendredi � ";
			break;	
		}
		if (hour <=4) {
			if (hour == 0) {
				s += 17+"h";
			}
			else {
				s += hour+8+"h";
			}
		}
		else {
			s += hour+9+"h";
		}
		return s;
	}
	
	//Compute Cmax and sum(Cj)
	public void calculPerf(ArrayList<IntVar[][]> listOF) {
		int Cmax = 0;
		int Cmean = 0;
		for (IntVar[][] OF : listOF) {
			Cmean += OF[OF.length-1][3].getValue();
			if (Cmax < OF[OF.length-1][3].getValue()) {
				Cmax = OF[OF.length-1][3].getValue();
			}
		}
		System.out.println("Performances :\n");
		System.out.println("Cmax :"+Cmax);
		System.out.println("Date de fin moyenne :"+Cmean);
	}
	
	public static void main(String[] args) {
		ChocoSolver l = new ChocoSolver();
		System.out.println(l.solve());
	}
	
}	
	

